package com.vinu.pet_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
